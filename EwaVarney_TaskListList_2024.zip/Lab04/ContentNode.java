/**
 * Ewa Varney
 * 03.20.2024
 * Lab04
 * Content Node
 */

import java.util.function.Predicate;

/**
 * A node with content
 */
public class ContentNode<T> implements Node<T> {
    private T content;
    private Node<T> next;

    /**
	 * Make a conent node
	 * then set next node to empty node
	 */
    public ContentNode(T content) {
        this.content = content;
        this.next = new EmptyNode<>();
    }

    /**
	 * Constructor to construct a content node with the content and the next node 
	 */
    public ContentNode(Node<T> next, T content) { // TA Dan advised on constructor
        this.next = next; // next node in list
        this.content = content; // content to be stored
    }
    
    /**
  	 * Methods implemented from node interface
  	 */
    @Override
    public int count() {
        return 1 + this.next.count();
    }
    
    
    @Override
    public void add(T task) {
        if (this.next instanceof EmptyNode) {
            this.next = new ContentNode<>(task); // TA Josh confirmed add logic works with ToDoList class
        } else {
            this.next.add(task);
        }
    }

    @Override
    public void remove(T task) {
        if (this.next instanceof ContentNode) {
            if (this.next.getContent().equals(task)) {
                this.next = this.next.getNext();
            } else {
                this.next.remove(task);
            }
        }
    }

    @Override
    public void complete(T task) {
        if (this.next instanceof ContentNode) {
            if (this.next.getContent().equals(task)) {
            } else {
                this.next.complete(task);
            }
        }
    }
    
    /**
  	 * Method to replace date with newDate 
  	 * it takes the task that needs to be replaced and the date it needs to be replaced with
  	 */
    @Override
    public void replaceDate(T task, Date newDate) {
        if (this.next instanceof ContentNode) {
            if (this.next.getContent().equals(task)) { 
            } else {
                this.next.replaceDate(task, newDate);
            }
        }
    }

    @Override
    public boolean isComplete(T task) {
        if (this.next instanceof ContentNode) {
            if (this.next.getContent().equals(task)) {
            } else {
                return this.next.isComplete(task);
            }
        }
        return false;
    }

    @Override
    public void print() {
        System.out.println(this.content);
        this.next.print();
    }

    @Override
    public void removeComplete() {
        if (this.next instanceof ContentNode) {
            this.next.removeComplete();
        }
    }

    @Override
    public void removeExpired() {
        if (this.next instanceof ContentNode) {
            this.next.removeExpired();
        }
    }
    
    /**
  	 * Prints the task based on the predicate
  	 * It needs to satisfy the condition
  	 */
    @Override
    public void print(Predicate<T> predicate) {
        Node<T> current = this;
        while (current != null) { // the node has content
            if (current instanceof ContentNode) {
                T task = ((ContentNode<T>) current).getContent(); // TA Josh advised on predicate
                if (predicate.test(task)) {
                    System.out.println(task);
                }
            }
            current = current.getNext();
        }
    }
    
    @Override
    public void printExpired() {
        if (this.next instanceof ContentNode) {
        }
    }

    /**
   	 * Getters and setters 
   	 * gets the node, gets the next node, then sets the next node
   	 */
    @Override
    public T getContent() {
        return this.content;
    }
    
    @Override
    public Node<T> getNext() {
        return this.next;
    }

    @Override
    public void setNext(Node<T> newNext) {
        this.next = newNext;
    }
}