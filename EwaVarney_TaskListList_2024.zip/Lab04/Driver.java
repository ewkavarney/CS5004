/**
 * Ewa Varney
 * 03.20.2024
 * Lab04
 * Driver
 */

public class Driver {
    public static void main(String[] args) {
    	/**
    	 * Make a Todo list
    	 */
        ToDoList<Task> toDoList = new ToDoList<>();

        Date date1 = new Date(2020, 5, 12);
        Date date2 = new Date(2024, 10, 16);
        Date date3 = new Date(2024, 10, 03);
        
    	/**
    	 * Add 3 tasks to the list
    	 */
        Task task1 = new Task(1, "Task 1", date1, false, Priority.LOW);
        Task task2 = new Task(2, "Task 2", date2, true, Priority.HIGH);
        Task task3 = new Task(3, "Task 3", date3, false, Priority.CRITICAL);
        
        toDoList.addTask(task1);
        toDoList.addTask(task2);
        toDoList.addTask(task3);

    	/**
    	 * Print tasks
    	 */
        System.out.println("All tasks ");
        toDoList.printAllTasks();
        System.out.println();

        /**
    	 * Count all tasks, completed tasks, and expired tasks using predicate
    	 */
        System.out.println("All tasks " + toDoList.countAllTasks());

        System.out.println("Completed tasks " + toDoList.countTasksWithPredicate(task -> task.isComplete()));

        System.out.println("Expired tasks " + toDoList.countTasksWithPredicate(task -> task.isExpired()));

        /**
    	 * Print expired tasks
    	 */
        System.out.println("\nExpired tasks ");
        toDoList.printExpiredTasks();
        System.out.println();

        /**
    	 * Count tasks of HIGH priority 
    	 */
        System.out.println("High priority tasks: " + toDoList.countTasksWithPredicate(task -> task.getPriority() == Priority.HIGH)); // TA Josh assisted me with this

        /**
    	 * Remove tasks then re-print task list
    	 */
        System.out.println("Remove completed");
        toDoList.removeTasksWithPredicate(task -> task.isComplete());

        System.out.println("\nUpdate task list");
        toDoList.printAllTasks();
        System.out.println();

        /**
    	 * Replace the date then print result
    	 */
        System.out.println("Update Date of first task ");
        Date newDate = new Date(2024, 03, 22);
        toDoList.changeTaskDate(task1, newDate);

        System.out.println("\nUpdated list ");
        toDoList.printAllTasks();
        System.out.println();

        /**
    	 * Remove tasks and print to check if all tasks are removed 
    	 */
        System.out.println("Remove all tasks ");
        toDoList.removeAllTasks();

        System.out.println("\nUpdate list ");
        toDoList.printAllTasks();
    }
}