/**
 * Ewa Varney
 * 03.25.2024
 * Task
 */

/**
 * Task has an id, desc, date, completed, priority level
 */
public class Task {
	private int id;
	private String description;
	private Date date;
	private boolean completed;
	private Priority priority;


	/**
	 * Constructor 
	 */
	public Task(int id, String description, Date date, boolean completed, Priority priority){
		this.id= id;
		this.description = description;
		this.date = date;
		this.completed = completed;
		this.priority = priority;
	}
	
	/**
	 * Method to check if completed: true or false
	 */
	public boolean isComplete() {
	    return completed;
	}
	
	/**
	 * Method to display if it is completed or not
	 */
	public void complete() {
		completed = true;
	}
	
	/**
	 * Method for expired, compares dates
	 */
    public boolean isExpired() {
        Date currentDate = new Date();
        
        if (date.getYear() < currentDate.getYear()) {
            return true;
        } else if (date.getYear() == currentDate.getYear() && date.getMonth() < currentDate.getMonth()) {
            return true;
        } else if (date.getYear() == currentDate.getYear() && date.getMonth() == currentDate.getMonth() && date.getDay() < currentDate.getDay()) {
            return true;
        } else {
            return false;
        }
    }
    
    
	/**
	 * Getters and setters 
	 */
	public int getId(){return id;}
	
	public String getDescription() {return description;}
	
	public Date getDate() {return date;}
	
	public boolean getCompleted() {return completed;}
	 
	public <T>Priority getPriority() {return priority;} // <T> before priority
	
	
	
    public void setId(int id) {this.id = id;}
    
    public void setDesc(String description) {this.description = description;}
    
    public void setDate(Date date) {this.date = date;}
    
    public void setCompleted(boolean completed) {this.completed = completed;}
    
    public void setPriority(Priority priority) {this.priority = priority;}
    
    
	/**
	 * ToString method 
	 */
    @Override
    public String toString() {
        return "Task{" + "id:" + id +
        		",description: " + description +
                ", date: " + date +
                ", completed " + completed +
                ", priority level" + priority +
                '}';
    }
}