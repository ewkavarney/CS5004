/**
 * Ewa Varney
 * 03.20.2024
 * Lab04
 * Node Interface
 */

import java.util.function.Predicate;

/**
 * Node interface includes methods empty node and content node will implement
 */

public interface Node<T> {
    int count();

    void add(T task);
    void remove(T task);
    void complete(T task);
    void replaceDate(T task, Date upDate);
    boolean isComplete(T task);
    void print();
    
    void removeComplete();
    void removeExpired();
    
    // not needed because using predicate
    // void printPriority(Priority priority);
    
    void print(Predicate<T> predicate);
    
    void printExpired();
    
    Node<T> getNext();
    void setNext(Node<T> next); 
    
    T getContent();
}

// Josh suggested I renamed task to item/date next time because it can store anything