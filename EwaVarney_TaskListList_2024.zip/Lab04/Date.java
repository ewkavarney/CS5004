/**
 * Ewa Varney
 * 03.20.2024
 * Lab04
 * Date
 */

/**
 * Date has a day, month, year
 */
public class Date {
	int day;
	int month;
	int year;

	/**
	 * Default constructor
	 */
	public Date() {}
	
	
	/**
	 * Constructor to initialize variables 
	 */
	public Date(int day, int month, int year) {
		this.day = day;
		this.month=month; 
		this.year= year;
	}
	
	/**
	 * Getters and setters
	 */
	public int getDay() {return day;}
	
	public int getMonth() {return month;}
	
	public int getYear() {return year;}
	
	
	/**
	 * day should never be less than 1 or exceed 31
	 * month should never exceed 12 
	 */
	public void setDay(int day) {
		if(day <1 || day>31) { throw new IllegalArgumentException();
		}
		this.day = day;
	}
		
	public void setMonth(int month) {
		if(month<1 || month>12) {throw new IllegalArgumentException("month should be greater than 0, but never exceed 12");
		}
		this.month=month;
	}
	
	public void setYear(int year) {
		this.year=year;
	}
	
	@Override
	public String toString() {
	    return String.format("%2d/%2d/%4d", day, month, year);
	}
}

	
