/**
 * Ewa Varney
 * 03.20.2024
 * Lab04
 * Empty Node
 */

import java.util.function.Predicate;

/**
 * EmptyNode implements Node<T>
 * An empty node doesn't store content and exists at the end
 */
public class EmptyNode<T> implements Node<T> {
	
    private Node<T> next;

    /**
     * Constructor
     */
    public EmptyNode() {
        this.next = null;
    }

    @Override
    public T getContent() {
 
        return null;
    }

    /**
     * Count method, returns 0 because empty
     */
    @Override
    public int count() {
        return 0;
    }

    @Override
    public void add(T task) {
        // add a task = create new node, then set as next
        this.next = new ContentNode<>(task);
    }

    /**
     * It is empty, so should it return without anything
     */
    
    @Override
    public void remove(T task) {

    }

    @Override
    public void complete(T task) {

    }

    /**
     * Method to replaceDate takes task object and updated date date object
     */
    @Override
    public void replaceDate(T task, Date upDate) {

    }

    /**
     * An empty node means there is no task to complete
     */
    @Override
    public boolean isComplete(T task) {

        return false;
    }

    @Override
    public void print() {
        System.out.println("No tasks in this node.");
    }

    @Override
    public void removeComplete() {

    }

    @Override
    public void removeExpired() {
   
    }

    /**
     * Prints contents in list given the predicate/condition
     */
    @Override
    public void print(Predicate<T> predicate) { // TA Josh advised on predicate 
    	
    }

    @Override
    public void printExpired() {
    	
    }

    @Override
    public Node<T> getNext() {
        return next;
    }

    @Override
    public void setNext(Node<T> next) {
        this.next = next;
    }
}