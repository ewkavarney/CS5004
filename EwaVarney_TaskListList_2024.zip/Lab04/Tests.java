/**
 * Ewa Varney
 * 03.25.2024
 * Tests
 */

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Tests for ToDolist methods: add, remove, completed
 */
public class Tests {

	/**
	 * Test add task method
	 */
    @Test
    public void testAddTask() {
        ToDoList<Task> toDoList = new ToDoList<>();
        Task task = new Task(1, "task 1", new Date(), false, Priority.LOW);
        
        toDoList.addTask(task);
        assertEquals(1, toDoList.countAllTasks());
    }

    /**
     * Test remove task method
     */
    @Test
    public void testRemoveTask() {
        ToDoList<Task> toDoList = new ToDoList<>();
        Task task = new Task(1, "task ", new Date(), false, Priority.LOW);
        
        toDoList.addTask(task);	
        toDoList.removeTask(task);
        assertEquals(1, toDoList.countAllTasks());
    }
    
    /**
     * Test completed task method
     */
    @Test
    public void testTaskCompleted() {
        Task task = new Task(1, "task", new Date(), false, Priority.LOW);
        assertFalse(task.isComplete());
        
        task.setCompleted(true);
        assertTrue(task.isComplete());
    }
}
