/**
 * Ewa Varney
 * 03.25.2024
 * ToDoList
 */

import java.util.function.Predicate;

public class ToDoList<T extends Task> {
    private Node<T> head;

    /**
     * Constructor for empty list
     */
    public ToDoList() {
        this.head = null;
    }

    /**
     * method to add task 
     */
    public void addTask(T task) {
        if (head == null) {
            head = new ContentNode<>(task);
        } else {
            head.add(task);
        }
    }

    /**
     * method to remove list
     */
    public void removeTask(T task) {
        if (head != null) {
            head.remove(task);
        }
    }
    
    /**
     * method to change date 
     */
    public void changeTaskDate(T task, Date newDate) {
        Node<T> current = head;
        while (current != null) {
            if (current instanceof ContentNode) {
                if (((ContentNode<T>) current).getContent().equals(task)) {
                    ((Task) task).setDate(newDate); // Casting to Task to use setDate method
                    return;
                }
            }
            current = current.getNext();
        }
    }

    /**
     * Count all tasks
     */
    public int countAllTasks() {
        return head.count();
    }

    /**
     * Counts all tasks based on specific condition (i.e. predicate)
     */
    public int countTasksWithPredicate(Predicate<T> predicate) {
        int count = 0;
        Node<T> current = head;
        while (current != null) {
            if (current instanceof ContentNode) {
                if (predicate.test(((ContentNode<T>) current).getContent())) {
                    count++;
                }
            }
            current = current.getNext();
        }
        return count;
    }

    /**
     * Removes all tasks based on specific condition (i.e. predicate: expired, completed, etc.)
     */
    public void removeTasksWithPredicate(Predicate<T> predicate) {
        Node<T> current = head;
        Node<T> prev = null;
        while (current != null) {
            if (current instanceof ContentNode) {
                if (predicate.test(((ContentNode<T>) current).getContent())) {
                    if (prev != null) {
                        prev.setNext(current.getNext());
                    } else {
                        head = current.getNext();
                    }
                } else {
                    prev = current;
                }
            }
            current = current.getNext();
        }
    }

    /**
     * Print all tasks
     */
    public void printAllTasks() {
        head.print();
    }

    /**
     * Print expired tasks
     */
    public void printExpiredTasks() {
        Predicate<T> expiredPredicate = task -> ((Task) task).isExpired();
        printTasksWithPredicate(expiredPredicate);
    }

    /**
     * Print all tasks based on specific condition (i.e. predicate)
     */
    private void printTasksWithPredicate(Predicate<T> predicate) {
        head.print(predicate);
    }
    
    public void removeAllTasks() {
        head = new EmptyNode<>();
    }
}

// constructor
// methods 
	

//implement head node
// head = test node
// make a list link interface and have methods in that (add, print)
// in TODO list - remove priority and other methods



