/**
 * Ewa Varney
 * 03.20.2024
 * Lab04
 * Priority ENUM
 */

/**
 * Priority can be low, high, critical 
 */

public enum Priority {
	LOW,
	HIGH,
	CRITICAL;
}
