/******
Name: Ewa Varney
Assignment: Lab 0
Date: 01.17.2024
Notes: 
******/

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertFalse;


/**
 * A JUnit test class for the Book class.
 */

public class BookTest {
	
	private Book twilight;
	private Person author;

/**
 * Default constructor.
 */

	public BookTest() {
		
	}
	
/**
 * Initializes the author variable as an instance of the Person class. 
 * Then the author object is used in the instance of the Book class.  
 */
	@Before
	public void setUp() {
		
		author = new Person("stephenie", "meyer", 1973);
		this.twilight = new Book("twilight", author, 22.50f);
	}

/**
 * The title returned should match.
 */
	@Test
	public void testTitle() {
		assertEquals("twilight", this.twilight.getTitle());
	}
	
/**
 * assertFalse test for the wrong title. 
 */	

	@Test
	public void testWrongTitle() {
		String wrongTitle = "twilite";
		assertFalse("wrong title", wrongTitle.equals(this.twilight.getTitle()));
	}
	
/**
 * The author's name should match expected first, last, and year.
 */
	@Test
	public void testAuthor() {
		assertEquals(author, this.twilight.getAuthor());
	}

/**
 * The price should match 22.50. The actual and expected must match exactly hence 0.0.
 */
	@Test
	public void testPrice() {
		assertEquals(22.50f, this.twilight.getPrice(), 0.0);
	}
}